# Cómo probar este backend

## 1. Preparar el proyecto

```bash
npm install
cp .env.example .env
```

Completá en `.env` los datos reales de tu base (`DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`)
y un `JWT_SECRET` (cualquier string).

```bash
npm start
```

El server queda escuchando en `http://localhost:3000`.

## 2. Ejecutar las pruebas

Abrí `requests.http`. Es un archivo de texto plano con todas las peticiones
(CRUD completo + pruebas de seguridad de token). Para ejecutarlo con un click:

- **VS Code**: instalá la extensión **REST Client** (`humao.rest-client`).
  Con el archivo abierto va a aparecer un link "Send Request" arriba de cada
  bloque separado por `###`.
- **IntelliJ / WebStorm**: no hace falta instalar nada, soporte nativo para `.http`.

Los tokens **se generan solos**: la sección 1 llama a `POST /auth/register`
(el punto de entrada real para conseguir un token) y las variables
`@profesorToken`, `@alumnoToken`, `@materiaId`, etc. se completan
automáticamente leyendo la respuesta de esos requests. No hay que copiar
ni pegar nada a mano — solo correr los bloques **en orden**, de arriba
hacia abajo:

1. **Health check** — server y DB responden.
2. **Auth** — registra profesor + 2 alumnos (quedan sus tokens e IDs
   guardados en variables), prueba email duplicado (409), type inválido
   (400), login por email (200) y login de email inexistente (404).
3. **Seguridad de token** — sin token, mal formado, vencido, firma falsa.
   Todos 401/403. Los dos últimos son los únicos tokens "hardcodeados"
   del archivo, porque son casos que la API nunca te va a dar por diseño.
4. **Users CRUD** — alta administrativa (solo profesor), lectura por
   id/email, update.
5. **Materias CRUD** — crear/leer/actualizar/borrar, con los 403 de alumno
   intentando escribir.
6. **Materia <-> Profesores** — alta/baja.
7. **Materia <-> Alumnos** — un alumno se anota/da de baja a sí mismo sin
   necesitar su propio UUID (sale del token); no puede tocar a otro alumno;
   el profesor sí puede gestionar a cualquiera.
8. **Limpieza** — borra materia y usuarios de prueba.

## 3. De dónde salen los tokens en producción

`POST /auth/register` (nombre, email, type) crea el usuario y devuelve
`{ user, token }` en la misma respuesta — no hace falta ningún paso manual.
`POST /auth/login` (email) devuelve un token nuevo para un usuario ya
existente. Ninguna de las dos rutas requiere token previo, porque son las
que lo generan.

⚠️ Simplificación a propósito: no hay contraseña (la tabla `users` no la
contempla). Para un sistema real habría que agregar `password_hash` y
validar con bcrypt en `/auth/login`.

## 4. Regenerar los tokens "inválidos" para los tests de seguridad

Si cambiás `JWT_SECRET` en `.env`, el `@fakeSignedToken` sigue sirviendo
igual (por definición está mal firmado), pero puede convenir regenerarlos:

```bash
JWT_SECRET=tu_clave node generate-test-tokens.js
```

Y reemplazá `@expiredToken` / `@fakeSignedToken` en `requests.http` por lo
que te imprima la consola.

## 5. Resultados esperados (resumen)

| Caso | Resultado esperado |
|---|---|
| `POST /auth/register` con datos válidos | 201, devuelve `{ user, token }` |
| `POST /auth/register` con email repetido | 409 |
| `POST /auth/login` con email inexistente | 404 |
| Request sin `Authorization` | 401 |
| Token mal formado / sin "Bearer " | 401 / 403 |
| Token vencido | 403 |
| Token con firma inválida | 403 |
| Alumno intenta `POST/PUT/DELETE` en `/materias` | 403 |
| Alumno lee `/materias` | 200 |
| Profesor crea/edita/borra materia | 200/201 |
| Alumno se anota a sí mismo en una materia | 201 |
| Alumno intenta anotar a otro alumno | 403 |
| Profesor anota a cualquier alumno | 201 |
